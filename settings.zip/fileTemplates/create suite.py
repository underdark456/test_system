import os
import getpass

__author__ = getpass.getuser()  # or place the author name manually, for instance 'dkudryashov'
# TODO:
'$PATH$'

def create_file():
    current_dir = os.path.dirname(__file__)
    options_path = current_dir[current_dir.find('test_scenarios/'):].replace(os.sep, '.')
    data = 'from src.custom_test_case import CustomTestCase\n' \
           'from src.drivers.drivers_provider import DriversProvider\n' \
           'from src.injection_container import InjectionContainer\n' \
           f"from {options_path} import subtests\n\n" \
           f"__author__ = '{__author__}'\n" \
           f"options_path = '{options_path}'\n\n\n" \
           f"class TestsRunner(CustomTestCase):\n\n" \
           f"    def test_run_all_tests_in_subtests(self):\n" \
           '        """Run all tests in folder subtests"""\n' \
           '        DriversProvider.set_test_suite()\n' \
           '        loader = InjectionContainer.get_loader()\n' \
           '        suite = loader.loadTestsFromModule(subtests)\n' \
           '        runner = InjectionContainer.get_runner() \n' \
           '        runner.run(suite)\n'

    with open('case_all_tickets_test.py', 'w') as f:
        f.write(data)


if __name__ == '__main__':
    create_file()